package com.kaiburr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiniProjectAsLayeredAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
