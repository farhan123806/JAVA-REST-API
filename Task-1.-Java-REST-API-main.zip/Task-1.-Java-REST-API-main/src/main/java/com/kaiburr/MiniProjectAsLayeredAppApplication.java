package com.kaiburr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MiniProjectAsLayeredAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(MiniProjectAsLayeredAppApplication.class, args);
	}

}
